// Crie a função addUser()
function ____ {
  // Obtenha o valor do usuário através das ids player1_name_input e player2_name_input

  // Armazene esses valores localmente

  // Atribua "game_page.html" para window.location
}

